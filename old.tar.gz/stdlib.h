#ifndef STDLIB_H_
#define STDLIB_H_

#include <stdio.h>
//char *snprintf(char *buf, unsigned int max, const char *format, ...);
float strtof(const char *s, char **endptr);

int atoi(const char *);

#endif // STDLIB_H_
