#ifndef MEMORY_H_
#define MEMORY_H_

void *malloc(unsigned int);
void *calloc(unsigned int, unsigned int);
void free(void *);

#endif // MEMORY_H_
