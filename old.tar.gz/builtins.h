#ifndef BUILTINS_H_
#define BUILTINS_H_

#include "parser.h"

#define IUP_COUNT 5
#define IDOWN_COUNT 3

void iload_core(interpreter *it);

void iret(interpreter *it, variable *v);

const func_t indent_up[IUP_COUNT];
const func_t indent_down[IDOWN_COUNT];

#endif // BUILTINS_H_
